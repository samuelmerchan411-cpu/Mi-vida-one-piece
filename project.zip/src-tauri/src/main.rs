#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    one_piece_life_simulator_lib::run();
}
