# One Piece Life Simulator V3 — Aplicación Android y PC

Este repositorio conserva el proyecto V3 y lo prepara para distribuirlo como **aplicación instalable** mediante Tauri 2:

- Android: APK instalable y AAB para distribución.
- Windows: instalador MSI/EXE según los targets de Tauri.
- Linux y macOS: paquetes nativos compilables desde sus respectivos sistemas.
- Una sola base de código y la misma partida/mecánicas en todas las plataformas.

No es necesario abrir Chrome para jugar. Tauri crea un paquete de aplicación y muestra la interfaz compartida en el WebView del sistema operativo. No es una interfaz nativa escrita en Kotlin/Swift, pero sí una aplicación instalable con ventana/launcher, icono y almacenamiento propio de la app.

## 1. Requisitos comunes

- Node.js 20.9+ (recomendado Node 22 LTS).
- npm.
- Rust estable y Cargo.
- Dependencias de compilación de Tauri para tu sistema operativo.

Instalación:
```bash
npm install
```

## 2. Android — generar APK

Necesitas:
- Android Studio.
- Android SDK (Platform Tools y Build Tools).
- Android SDK Platform 35 o la que indique el entorno Tauri instalado.
- Android NDK y CMake instalados desde SDK Manager.
- Java/JDK 17.
- Rust con targets Android instalados; Tauri/Android init configura la parte del proyecto.

Configura `ANDROID_HOME`/`ANDROID_SDK_ROOT` y `JAVA_HOME` según la ruta de Android Studio. En Windows normalmente Android Studio permite localizar estas rutas en SDK Manager.

Inicializa el proyecto Android una sola vez:
```bash
npm run android:init
```

Conecta un teléfono con depuración USB o inicia un emulador:
```bash
npm run android:dev
```

Compila APK de lanzamiento:
```bash
npm run android:apk
```

Compila AAB para Google Play:
```bash
npm run android:aab
```

Los resultados se generan dentro de:
```text
src-tauri/gen/android/app/build/outputs/
```

El APK puede instalarse directamente en Android (permitiendo instalar aplicaciones desde esa fuente). El AAB se usa para distribución en Google Play. La primera compilación necesita descargar dependencias de Gradle/Rust.

**Importante:** el ZIP contiene la configuración Tauri para Android, pero no incluye `src-tauri/gen/android/`: esa carpeta la crea el comando `android:init` en el equipo que tenga Android Studio/SDK instalado. No es posible generar un APK fiable sin ese toolchain.

## 3. PC — aplicación instalable

En Windows:
```bash
npm run desktop:dev
npm run desktop:build
```

Los instaladores se generan dentro de:
```text
src-tauri/target/release/bundle/
```

Dependiendo de los targets habilitados, Tauri genera instalador `.msi` o `.exe` (NSIS). La compilación de Windows debe hacerse en Windows. Para Linux y macOS, compila en cada sistema operativo siguiendo los requisitos oficiales de Tauri.

## 4. Mismo código para móvil y PC

La interfaz adapta sus paneles a pantallas pequeñas y grandes. Android y PC usan la misma lógica, la misma ruleta y el mismo formato de guardado. Las partidas se guardan en el almacenamiento local de la aplicación en cada dispositivo.

Para pasar una partida entre Android y PC:
1. Exporta el archivo JSON desde la pantalla de partidas.
2. Transfiere el archivo al otro dispositivo.
3. Importa el JSON en la aplicación de destino.

No hay sincronización automática en la nube todavía.

## 5. IA y backend

La IA es opcional. El motor local debe seguir narrando si el proveedor no está disponible.

El servicio Node de narración se inicia por separado:
```bash
npm run api
```

Para desarrollo local de escritorio, configura `.env.local`:
```env
NEXT_PUBLIC_NARRATOR_URL=http://127.0.0.1:8787/api/narrate
```

En Android, `127.0.0.1` apunta al propio teléfono, no al PC. Para usar un servidor de IA instalado en otro equipo de tu red, configura la dirección LAN de ese equipo, por ejemplo:
```env
NEXT_PUBLIC_NARRATOR_URL=http://192.168.1.50:8787/api/narrate
```
Cambia la IP por la dirección real de tu servidor. Para conexiones fuera de una red privada, usa HTTPS. No publiques claves API en el frontend. El proveedor y la clave se configuran desde la aplicación y se envían al servicio backend; no deben escribirse en el repositorio.

Para un servicio de IA remoto, configura la URL HTTPS pública del backend antes de compilar la app.

## 6. Retrato anime de la mejor era

En la ficha del personaje aparece el botón **Ver mi mejor era**. La aplicación envía al backend los datos de la partida (edad, afiliación, poderes, estadísticas, recompensa, tripulación y últimos hitos) y solicita una ilustración original a OpenAI Images (`gpt-image-1`). El retrato se reduce a 640×640 y se guarda junto a la partida local para que siga visible al volver a abrirla.

Requisitos:
- En Configuración, selecciona **OpenAI**.
- Añade una clave API con acceso a generación de imágenes.
- Ejecuta el backend con `npm run api`.
- Para Android/PC empaquetados, configura `NEXT_PUBLIC_NARRATOR_URL` apuntando a un backend accesible por HTTPS, por ejemplo `https://tu-servidor.example/api/narrate`. La ruta de retratos se deriva automáticamente como `/api/portrait`.
- Si usas un endpoint personalizado compatible con OpenAI Images, selecciona **Compatible / personalizado** e indica la URL base que termina en `/v1`.

Los proveedores Gemini, Claude y OpenRouter siguen disponibles para narración de texto; la generación de retratos de esta versión usa OpenAI Images o un endpoint compatible. La generación requiere internet y puede tener coste según tu cuenta/API. La imagen es original y representa al personaje de la partida; no altera sus estadísticas ni la historia.

## 7. Guardado

- Guardado automático local de partidas.
- Varias partidas.
- Exportar/importar JSON.
- La información queda en cada dispositivo; reinstalar/borrar datos de la app puede eliminar las partidas locales. Exporta copias de seguridad.

## 8. Solución de problemas

- `tauri android init` no encuentra Android SDK: instala Android Studio/SDK y define `ANDROID_HOME` o `ANDROID_SDK_ROOT`.
- Error de Java/Gradle: usa JDK 17 y comprueba `JAVA_HOME`.
- Error de Rust target: instala el target Android requerido por Tauri y vuelve a ejecutar `npm run android:init`.
- Android no puede acceder al backend: no uses `127.0.0.1` si el backend está en otro dispositivo; usa la IP LAN del servidor y permite el puerto en el firewall.
- El build web estático falla: ejecuta `npm run build:desktop` y revisa los errores antes de compilar el wrapper.

## 9. Estado real de esta entrega

Preparado en el código:
- Configuración Tauri 2 compartida para escritorio y Android.
- Scripts de inicialización, desarrollo y compilación Android APK/AAB.
- Scripts de desarrollo y compilación desktop.
- Identificador de aplicación `com.grandline.life-simulator`.
- Android mínimo API 24 (Android 7.0).
- Interfaz compartida y adaptable.

Pendiente de ejecutar en un equipo de compilación:
- `npm install`.
- `npm run android:init`.
- Compilación APK/AAB en Android SDK instalado.
- Compilación MSI/EXE en Windows.
- Prueba de instalación y funcionamiento en un dispositivo Android y PC reales.

No se afirma que ya exista un APK o instalador compilado en este ZIP. Este paquete entrega el código y la configuración para producirlos en el entorno adecuado.


## Dirección visual V3.1
Se reemplazó la apariencia sobria tipo pergamino por una dirección anime/manga: azul marino, cian, coral y amarillo; tipografía de cómic; paneles con contornos gruesos y sombras; botones de alto contraste; navegación táctil más compacta y ficha de personaje con retrato.


## Dirección V3.3 — Ruleta total
La creación de vida ya no ofrece elecciones de mar, isla ni origen. La primera tirada sortea automáticamente uno de los cuatro Blues o Grand Line, una isla de ese mar, familia, clase social, oficio y nombre. Los acontecimientos con decisiones se resuelven automáticamente mediante probabilidades; no aparecen ventanas que pidan escoger entre opciones. La interfaz se reorganiza con una paleta verde océano, oro envejecido y paneles más limpios, priorizando la ruleta y el resultado de cada tirada.
