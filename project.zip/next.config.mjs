/** @type {import('next').NextConfig} */
const nextConfig = {
  ...(process.env.TAURI_BUILD === '1' ? { output: 'export' } : {}),
  images: { unoptimized: true },
}
export default nextConfig
