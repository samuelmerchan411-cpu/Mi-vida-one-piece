import { createServer } from 'node:http'
const PORT=Number(process.env.PORT||8787)
const allowed=(process.env.CORS_ORIGIN||'http://localhost:3000,http://127.0.0.1:3000,tauri://localhost,http://tauri.localhost,https://tauri.localhost').split(',').map(x=>x.trim())
const server=createServer(async(req,res)=>{
 const origin=req.headers.origin||''
 if(origin&& !allowed.includes(origin)){res.writeHead(403);return res.end('Origin not allowed')}
 res.setHeader('Vary','Origin');if(origin)res.setHeader('Access-Control-Allow-Origin',origin)
 res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS')
 res.setHeader('Access-Control-Allow-Headers','Content-Type')
 if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
 if(req.method!=='POST'||!['/api/narrate','/api/portrait'].includes(req.url)){res.writeHead(404);return res.end('Not found')}
 try{
  let raw='';for await(const chunk of req)raw+=chunk
  if(raw.length>100000){res.writeHead(413);return res.end(JSON.stringify({error:'Request too large'}))}
  const body=JSON.parse(raw),c=body.config||{},provider=c.provider||'openai',model=c.model||'gpt-4o-mini',key=c.apiKey||''
  if(req.url==='/api/portrait'){
   if(!key)throw Error('Falta la clave API de OpenAI.')
   if(!['openai','custom'].includes(provider))throw Error('La generación de retratos está disponible con OpenAI o un endpoint compatible con OpenAI Images.')
   const baseRaw=c.baseUrl||'https://api.openai.com/v1'; const base=baseRaw.endsWith('/')?baseRaw.slice(0,-1):baseRaw
   const imageUrl=`${base}/images/generations`
   const parsedImageUrl=new URL(imageUrl)
   if(parsedImageUrl.protocol!=='https:')throw Error('El endpoint de imágenes debe usar HTTPS.')
   const ch=body.character||{}
   const stats=ch.stats||{}
   const strongest=Object.entries(stats).sort((a,b)=>Number(b[1])-Number(a[1])).slice(0,4).map(([k,v])=>`${k}: ${v}/100`).join(', ')
   const prompt=`Create a high-quality original anime pirate-adventure character illustration, full-color Japanese shonen manga key visual. Depict the SAME original character described below at their prime / best era, not as a generic pirate. Character name: ${ch.name||'Unknown'}. Age at prime: ${Math.max(18,Math.min(35,Number(ch.age)||25))}. Role: ${ch.profession||'adventurer'}. Affiliation: ${ch.faction||'independent'}. Location and sea: ${ch.location||'open sea'}, ${ch.sea||''}. Devil Fruit/power: ${ch.fruit||'none known'}. Bounty: ${Number(ch.wanted||0).toLocaleString('en-US')} berries. Level: ${ch.level||1}. Strongest attributes: ${strongest||'balanced fighter'}. Crew: ${(ch.crew||[]).join(', ')||'travels alone'}. Recent life milestones: ${(ch.history||[]).join('; ')||'a life of adventure'}. Design a distinctive original face, hairstyle, outfit, silhouette, weapons and aura that visually communicate these facts. Dynamic heroic pose, expressive face, dramatic ocean and ship background, bold clean line art, vivid cel shading, energetic composition, polished anime character art, rich detail. Make the character the clear focal point. No text, no logos, no watermark, no existing copyrighted character.`
   const imageResponse=await fetch(imageUrl,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model:'gpt-image-1',prompt,size:'1024x1024',quality:'high',output_format:'png'}),signal:AbortSignal.timeout(120000)})
   const imageData=await imageResponse.json().catch(()=>({}))
   if(!imageResponse.ok)throw Error(imageData?.error?.message||`El proveedor de imágenes respondió ${imageResponse.status}`)
   const b64=imageData?.data?.[0]?.b64_json
   if(typeof b64!=='string'||!b64)throw Error('El proveedor no devolvió la imagen en formato esperado.')
   res.writeHead(200,{'Content-Type':'application/json'});return res.end(JSON.stringify({image:`data:image/png;base64,${b64}`}))
  }
  const prompt=`Eres narrador de una partida de One Piece. Amplía narrativamente SOLO el acontecimiento que ya decidió el motor. No cambies sus hechos, no inventes encuentros con personajes canon, no contradigas memoria ni cronología. Si un dato no está en el contexto, no lo afirmes. Personaje: ${body.character||'Aventurero'}. Acontecimiento decidido: ${JSON.stringify(body.event||{})}. Memoria reciente: ${JSON.stringify(body.memory||[])}. Escribe 2-4 frases en español, inmersivas y coherentes. Devuelve solo la narración.`
  let url='',headers={'Content-Type':'application/json'},payload
  if(provider==='gemini'){if(!key)throw Error('Falta la clave API de Gemini.');url=c.baseUrl||`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;payload={contents:[{parts:[{text:prompt}]}]}}
  else if(provider==='anthropic'){if(!key)throw Error('Falta la clave API de Anthropic.');url=c.baseUrl||'https://api.anthropic.com/v1/messages';headers['x-api-key']=key;headers['anthropic-version']='2023-06-01';payload={model,max_tokens:350,messages:[{role:'user',content:prompt}]}}
  else{if(provider!=='ollama'&&!key)throw Error('Falta la clave API.');const base=c.baseUrl||(provider==='ollama'?'http://127.0.0.1:11434/v1':provider==='openrouter'?'https://openrouter.ai/api/v1':'https://api.openai.com/v1');if(provider==='custom'&&!c.baseUrl)throw Error('Indica la URL base del proveedor personalizado.');url=`${base.replace(/\/$/,'')}/chat/completions`;if(key)headers.Authorization=`Bearer ${key}`;payload={model,messages:[{role:'system',content:'Respeta los hechos establecidos.'},{role:'user',content:prompt}],temperature:.7,max_tokens:350}}
  const parsed=new URL(url);if(parsed.protocol!=='https:'&&!(provider==='ollama'&&['localhost','127.0.0.1'].includes(parsed.hostname)))throw Error('El endpoint debe usar HTTPS (Ollama local puede usar localhost).')
  const response=await fetch(url,{method:'POST',headers,body:JSON.stringify(payload),signal:AbortSignal.timeout(25000)}),data=await response.json().catch(()=>({}))
  if(!response.ok)throw Error(data?.error?.message||`El proveedor respondió ${response.status}`)
  const narrative=provider==='gemini'?data?.candidates?.[0]?.content?.parts?.map(p=>p.text).join(' '):provider==='anthropic'?data?.content?.map(p=>p.text).join(' '):data?.choices?.[0]?.message?.content
  if(typeof narrative!=='string'||!narrative.trim())throw Error('El proveedor no devolvió una narración válida.')
  res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({narrative:narrative.trim()}))
 }catch(e){res.writeHead(502,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e instanceof Error?e.message:'Narrador no disponible'}))}
})
server.listen(PORT,process.env.HOST||'127.0.0.1',()=>console.log(`Narrator API listening on ${PORT}`))
