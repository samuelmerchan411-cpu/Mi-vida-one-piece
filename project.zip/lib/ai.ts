// Llamadas directas a proveedores de IA desde la app (sin servidor propio).
// La clave la escribe el usuario en Configuración y solo viaja al proveedor elegido.
export type AIConfig={provider?:string;model?:string;apiKey?:string;baseUrl?:string;imageProvider?:string;imageModel?:string;imageKey?:string;imageBaseUrl?:string}
export const IMAGE_PROVIDERS=['openai','gemini','openrouter','custom','pollinations']
const clean=(u:string)=>u.replace(/\/+$/,'')
const assertHttps=(url:string,local=false)=>{const u=new URL(url);if(u.protocol!=='https:'&&!(local&&['localhost','127.0.0.1'].includes(u.hostname)))throw new Error('El endpoint debe usar HTTPS (solo Ollama puede usar localhost).')}

async function http(url:string,init:RequestInit,ms:number):Promise<Response>{
 const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),ms)
 try{return await fetch(url,{...init,signal:ctl.signal})}
 catch(e:any){throw new Error(e?.name==='AbortError'?'El proveedor tardó demasiado en responder.':'No se pudo conectar con el proveedor: revisa tu internet o la URL. Algunos servicios no aceptan llamadas directas desde la app.')}
 finally{clearTimeout(t)}
}
async function postJson(url:string,headers:Record<string,string>,body:unknown,ms:number):Promise<any>{
 const r=await http(url,{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)},ms)
 const j:any=await r.json().catch(()=>({}))
 if(!r.ok)throw new Error((typeof j?.error==='string'?j.error:j?.error?.message)||j?.message||`El proveedor respondió ${r.status}`)
 return j
}
async function blobToDataUrl(blob:Blob,fallbackType='image/png'):Promise<string>{
 const bytes=new Uint8Array(await blob.arrayBuffer());let bin='';for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode(...bytes.subarray(i,i+0x8000))
 return `data:${blob.type||fallbackType};base64,${btoa(bin)}`
}
async function urlToDataUrl(url:string):Promise<string>{
 assertHttps(url)
 const r=await http(url,{},60000);if(!r.ok)throw new Error(`No se pudo descargar la imagen (${r.status}).`)
 return blobToDataUrl(await r.blob())
}

export async function narrate(c:AIConfig,event:unknown,memory:unknown,character:string):Promise<string>{
 const provider=c.provider||'openai',model=c.model||'gpt-4o-mini',key=c.apiKey||''
 const prompt=`Eres narrador de una partida de One Piece. Amplía narrativamente SOLO el acontecimiento que ya decidió el motor. No cambies sus hechos, no inventes encuentros con personajes canon, no contradigas memoria ni cronología. Si un dato no está en el contexto, no lo afirmes. Personaje: ${character||'Aventurero'}. Acontecimiento decidido: ${JSON.stringify(event||{})}. Memoria reciente: ${JSON.stringify(memory||[])}. Escribe 2-4 frases en español, inmersivas y coherentes. Devuelve solo la narración.`
 let url='',payload:any;const headers:Record<string,string>={}
 if(provider==='gemini'){
  if(!key)throw new Error('Falta la clave API de Gemini.')
  url=c.baseUrl||`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`
  headers['x-goog-api-key']=key;payload={contents:[{parts:[{text:prompt}]}]}
 }else if(provider==='anthropic'){
  if(!key)throw new Error('Falta la clave API de Claude.')
  url=c.baseUrl||'https://api.anthropic.com/v1/messages'
  headers['x-api-key']=key;headers['anthropic-version']='2023-06-01';headers['anthropic-dangerous-direct-browser-access']='true'
  payload={model,max_tokens:350,messages:[{role:'user',content:prompt}]}
 }else{
  if(provider!=='ollama'&&!key)throw new Error('Falta la clave API.')
  if(provider==='custom'&&!c.baseUrl)throw new Error('Indica la URL base del proveedor personalizado.')
  const base=c.baseUrl||(provider==='ollama'?'http://127.0.0.1:11434/v1':provider==='openrouter'?'https://openrouter.ai/api/v1':'https://api.openai.com/v1')
  url=`${clean(base)}/chat/completions`;if(key)headers.Authorization=`Bearer ${key}`
  payload={model,messages:[{role:'system',content:'Respeta los hechos establecidos.'},{role:'user',content:prompt}],temperature:.7,max_tokens:350}
 }
 assertHttps(url,provider==='ollama')
 const data=await postJson(url,headers,payload,25000)
 const text=provider==='gemini'?data?.candidates?.[0]?.content?.parts?.map((p:any)=>p.text).join(' '):provider==='anthropic'?data?.content?.map((p:any)=>p.text).join(' '):data?.choices?.[0]?.message?.content
 if(typeof text!=='string'||!text.trim())throw new Error('El proveedor no devolvió una narración válida.')
 return text.trim()
}

export function imageTarget(c:AIConfig):{ok:boolean;msg:string;provider:string;key:string}{
 const p=c.imageProvider&&c.imageProvider!=='auto'?c.imageProvider:(IMAGE_PROVIDERS.includes(c.provider||'')?(c.provider as string):'')
 const no=(msg:string)=>({ok:false,msg,provider:p,key:''})
 if(!p)return no('Elige un proveedor de imágenes en Configuración: OpenAI, Gemini, OpenRouter, compatible con OpenAI o Pollinations (gratis). Claude y Ollama no generan imágenes.')
 if(!IMAGE_PROVIDERS.includes(p))return no('Ese proveedor no genera imágenes. Elige otro en Configuración.')
 const key=c.imageKey||(p===c.provider?c.apiKey:'')||''
 if(p!=='pollinations'&&!key)return no('Añade la clave API del proveedor de imágenes en Configuración.')
 if(p==='custom'&&!(c.imageBaseUrl||(c.provider==='custom'&&c.baseUrl)))return no('Indica la URL base del servicio de imágenes compatible con OpenAI.')
 return {ok:true,msg:'',provider:p,key}
}

export async function generateImage(c:AIConfig,ch:any):Promise<string>{
 const t=imageTarget(c);if(!t.ok)throw new Error(t.msg)
 const stats=ch.stats||{}
 const strongest=Object.entries(stats).sort((a:any,b:any)=>Number(b[1])-Number(a[1])).slice(0,4).map(([k,v])=>`${k}: ${v}/100`).join(', ')
 const age=Math.max(18,Math.min(35,Number(ch.age)||25))
 const prompt=`Create a high-quality original anime pirate-adventure character illustration, full-color Japanese shonen manga key visual. Depict the SAME original character described below at their prime / best era, not as a generic pirate. Character name: ${ch.name||'Unknown'}. Age at prime: ${age}. Role: ${ch.profession||'adventurer'}. Affiliation: ${ch.faction||'independent'}. Location and sea: ${ch.location||'open sea'}, ${ch.sea||''}. Devil Fruit/power: ${ch.fruit||'none known'}. Bounty: ${Number(ch.wanted||0).toLocaleString('en-US')} berries. Level: ${ch.level||1}. Strongest attributes: ${strongest||'balanced fighter'}. Crew: ${(ch.crew||[]).join(', ')||'travels alone'}. Recent life milestones: ${(ch.history||[]).join('; ')||'a life of adventure'}. Design a distinctive original face, hairstyle, outfit, silhouette, weapons and aura that visually communicate these facts. Dynamic heroic pose, expressive face, dramatic ocean and ship background, bold clean line art, vivid cel shading, energetic composition. Make the character the clear focal point. No text, no logos, no watermark, no existing copyrighted character.`
 const p=t.provider,key=t.key
 if(p==='gemini'){
  const base=clean(c.imageBaseUrl||'https://generativelanguage.googleapis.com/v1beta'),model=c.imageModel||'gemini-2.5-flash-image'
  const url=`${base}/models/${encodeURIComponent(model)}:generateContent`;assertHttps(url)
  const j=await postJson(url,{'x-goog-api-key':key},{contents:[{parts:[{text:prompt}]}],generationConfig:{responseModalities:['TEXT','IMAGE']}},120000)
  const parts:any[]=j?.candidates?.[0]?.content?.parts||[]
  const img=parts.map(x=>x.inlineData||x.inline_data).find(Boolean)
  if(img?.data)return `data:${img.mimeType||img.mime_type||'image/png'};base64,${img.data}`
  throw new Error(parts.map(x=>x.text).filter(Boolean).join(' ')||j?.promptFeedback?.blockReason||'Gemini no devolvió una imagen (el contenido pudo ser bloqueado o el modelo no genera imágenes).')
 }
 if(p==='openrouter'){
  const base=clean(c.imageBaseUrl||'https://openrouter.ai/api/v1'),model=c.imageModel||'google/gemini-2.5-flash-image'
  const url=`${base}/chat/completions`;assertHttps(url)
  const j=await postJson(url,{Authorization:`Bearer ${key}`},{model,messages:[{role:'user',content:prompt}],modalities:['image','text']},120000)
  const u=j?.choices?.[0]?.message?.images?.[0]?.image_url?.url
  if(typeof u==='string'&&u.startsWith('data:'))return u
  if(typeof u==='string')return urlToDataUrl(u)
  throw new Error('OpenRouter no devolvió una imagen: comprueba que el modelo genere imágenes.')
 }
 if(p==='pollinations'){
  const short=`anime pirate adventure character portrait, shonen manga key visual, ${ch.profession||'adventurer'}, ${ch.faction||'independent'}, age ${age}, ${ch.fruit?'devil fruit power aura, ':''}${ch.wanted?'famous pirate with a bounty, ':''}dynamic heroic pose, ocean and ship background, vivid cel shading, no text, no logo`.slice(0,700)
  const base=clean(c.imageBaseUrl||'https://image.pollinations.ai/prompt'),model=c.imageModel||'flux'
  const url=`${base}/${encodeURIComponent(short)}?model=${encodeURIComponent(model)}&width=768&height=768&nologo=true&seed=${Math.floor(Math.random()*1e6)}`;assertHttps(url)
  const r=await http(url,{},120000)
  if(!r.ok)throw new Error(`Pollinations respondió ${r.status}. Prueba más tarde o usa otro proveedor.`)
  const b=await r.blob();if(!(b.type||'').startsWith('image/'))throw new Error('Pollinations no devolvió una imagen.')
  return blobToDataUrl(b)
 }
 // openai y compatibles con OpenAI Images
 const base=clean(p==='custom'?(c.imageBaseUrl||c.baseUrl||''):(c.imageBaseUrl||'https://api.openai.com/v1'))
 const model=c.imageModel||(p==='openai'?'gpt-image-1':'')
 if(!model)throw new Error('Indica el nombre del modelo de imagen en Configuración.')
 const url=`${base}/images/generations`;assertHttps(url)
 const body:any={model,prompt,size:'1024x1024'}
 if(model.startsWith('gpt-image')){body.quality='medium';body.output_format='png'}else body.response_format='b64_json'
 const j=await postJson(url,{Authorization:`Bearer ${key}`},body,120000)
 const d=j?.data?.[0]
 if(d?.b64_json)return `data:image/png;base64,${d.b64_json}`
 if(d?.url)return urlToDataUrl(d.url)
 throw new Error('El proveedor no devolvió la imagen en el formato esperado.')
}
